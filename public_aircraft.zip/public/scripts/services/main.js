/*
 * load angular app.services files - angular.module("app.services");
 */
define(['./sample-service','./predix-asset-service'], function() {

});
