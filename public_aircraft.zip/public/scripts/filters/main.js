/*
 * load angular app.filters files - angular.module("app.filters");
 */
define(['./sample-filter'], function() {

});
