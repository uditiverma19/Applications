jQuery(document).ready(function() {

 	$("#aircraftSubmitID").click(function (event) {

	var searchaircraftId = $("#aircraftId").val();

	var searchairspeed = $("#airspeed").val();

	var searcharmRetardantTankDoor = $("#armRetardantTankDoor").val();

	var searchbeaconStartStopRecording = $("#beaconStartStopRecording").val();

	var searchelapsedTime = $("#elapsedTime").val();

	var searchelevatorPosition = $("#elevatorPosition").val();

	var searchflapPosition = $("#flapPosition").val();

	var searchgearUpAndLocked = $("#gearUpAndLocked").val();

	var searchleftAileronPosition = $("#leftAileronPosition").val();

	var searchpeakValleyIndicator = $("#peakValleyIndicator").val();

	var searchpressureAltitude = $("#pressureAltitude").val();

	var searchrecordType = $("#recordType").val();

	var searchretardantDoorOpen = $("#retardantDoorOpen").val();

	var searchretardantTankFloat = $("#retardantTankFloat").val();

	var searchrollAcceleration = $("#rollAcceleration").val();

	var searchstrainGauge1 = $("#strainGauge1").val();

	var searchstrainGauge2 = $("#strainGauge2").val();

	var searchstrainGauge3 = $("#strainGauge3").val();

	var searchstrainGauge4 = $("#strainGauge4").val();

	var searchstrainGauge5 = $("#strainGauge5").val();

	var searchstrainGauge6 = $("#strainGauge6").val();

	var searchstrainGauge7 = $("#strainGauge7").val();

	var searchstrainGauge8 = $("#strainGauge8").val();

	var searchtimestamp = $("#timestamp").val();

	var searchtriggerChannel = $("#triggerChannel").val();

	var searchverticalAcceleration = $("#verticalAcceleration").val();

	//alert("searchPO"+searchPONbr);

searchGridData(searchaircraftId, searchairspeed, searcharmRetardantTankDoor, searchbeaconStartStopRecording, searchelapsedTime, searchelevatorPosition, searchflapPosition, searchgearUpAndLocked, searchleftAileronPosition, searchpeakValleyIndicator, searchpressureAltitude, searchrecordType, searchretardantDoorOpen, searchretardantTankFloat, searchrollAcceleration, searchstrainGauge1, searchstrainGauge2, searchstrainGauge3, searchstrainGauge4, searchstrainGauge5, searchstrainGauge6, searchstrainGauge7, searchstrainGauge8, searchtimestamp, searchtriggerChannel, searchverticalAcceleration);

   });


  $("#aircraftClearBtnID").click(function (event) {

  jQuery("#aircraftId").val("");

  jQuery("#airspeed").val("");

  jQuery("#armRetardantTankDoor").val("");

  jQuery("#beaconStartStopRecording").val("");

  jQuery("#elapsedTime").val("");

	jQuery("#elevatorPosition").val("");

  jQuery("#airspeed").val("");

  jQuery("#armRetardantTankDoor").val("");

  jQuery("#beaconStartStopRecording").val("");

  jQuery("#elapsedTime").val("");

	jQuery("#aircraftId").val("");

  jQuery("#airspeed").val("");

  jQuery("#armRetardantTankDoor").val("");

  jQuery("#beaconStartStopRecording").val("");

  jQuery("#elapsedTime").val("");

	jQuery("#aircraftId").val("");

  jQuery("#airspeed").val("");

  jQuery("#armRetardantTankDoor").val("");

  jQuery("#beaconStartStopRecording").val("");

  jQuery("#elapsedTime").val("");

	jQuery("#aircraftId").val("");

  jQuery("#airspeed").val("");

  jQuery("#armRetardantTankDoor").val("");

  jQuery("#beaconStartStopRecording").val("");

  jQuery("#elapsedTime").val("");

  searchGridData('', '', '', '', '');

});


  /* $("#multipleSelect1").change(function() {

      multipleSelect = $("#multipleSelect1").val();
	});

      function saveRows() {
		if(multipleSelect=="Save"){

              var grid = $("#list");

              var ids = grid.jqGrid('getDataIDs');

              var poNumber;

              for (var i = 0; i < ids.length; i++) {

                celValue = grid.jqGrid ('getCell', ids[1], 'quantityType');

               if ($('#jqg_list_'+ids[i]).is(':checked')){

                  poNumber = grid.jqGrid ('getCell', ids[i], 'poNumber');

                }

                if(celValue=="Planned for Supplier")

                {

                      grid.jqGrid('saveRow', ids[i]);

                      var rowEdit = grid.jqGrid('getRowData', ids[i]);

                      var saveRowdata = $("#list").jqGrid("getGridParam", "data");

                      var postRowdata = JSON.stringify(rowEdit).replace(/]|[[]/g, '');

                   // alert("rowData:  "+postRowdata);

                    console.log(postRowdata);

                 $.ajax({

                    url: "http://scp-transport-demand-portal.run.aws-usw02-pr.ice.predix.io/view/updateDemandDetails",

                    type: "POST", //send it through post method

                    data : postRowdata,

                    headers : {

                    'Content-Type' : 'application/json'

                  },

                success: function(responseData) {

                  jQuery('#list').jqGrid('setGridParam', {data: rowEdit});

                  var newGridData = $("#list").jqGrid("getGridParam", "data");

                  startEdit();

                  searchData('','','','');

                  //reloadMainGridData(newGridData);

                },

                error: function ( xhr, status, error) {

                    alert( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error);

                }

                });

                }

               }

             }

             else

             {

              alert("Select Save Option to proceed.");

             }

        } */


  function searchGridData(searchaircraftId, searchairspeed, searcharmRetardantTankDoor, searchbeaconStartStopRecording, searchelapsedTime, searchelevatorPosition, searchflapPosition, searchgearUpAndLocked, searchleftAileronPosition, searchpeakValleyIndicator, searchpressureAltitude, searchrecordType, searchretardantDoorOpen, searchretardantTankFloat, searchrollAcceleration, searchstrainGauge1, searchstrainGauge2, searchstrainGauge3, searchstrainGauge4, searchstrainGauge5, searchstrainGauge6, searchstrainGauge7, searchstrainGauge8, searchtimestamp, searchtriggerChannel, searchverticalAcceleration){

    var searchitemdata = {aircraftId:searchaircraftId, airspeed:searchairspeed, armRetardantTankDoor:searcharmRetardantTankDoor, beaconStartStopRecording:searchbeaconStartStopRecording, elapsedTime:searchelapsedTime, elevatorPosition:searchelevatorPosition, flapPosition:searchflapPosition, gearUpAndLocked:searchgearUpAndLocked, leftAileronPosition:searchleftAileronPosition, peakValleyIndicator:searchpeakValleyIndicator, pressureAltitude:searchpressureAltitude, recordType:searchrecordType, retardantDoorOpen:searchretardantDoorOpen, retardantTankFloat:searchretardantTankFloat, rollAcceleration:searchrollAcceleration, strainGauge1:searchstrainGauge1, strainGauge2:searchstrainGauge2, strainGauge3:searchstrainGauge3, strainGauge4:searchstrainGauge4, strainGauge5:searchstrainGauge5, strainGauge6:searchstrainGauge6, strainGauge7:searchstrainGauge7, strainGauge8:searchstrainGauge8, timestamp:searchtimestamp, triggerChannel:searchtriggerChannel, verticalAcceleration:searchverticalAcceleration};

	var postData = JSON.stringify(searchitemdata);

	console.log('resultData--filedSeletcedButtonID'+postData);



/* if(searchPONbr !='' || searchInvoiceNbr !='' || searchInvoiceAmt !='' || searchInvoiceSbtDt !='' || searchPayNumber !=''){

$.ajax({



	url: "https://scpcrpinvoicedetail.run.aws-usw02-pr.ice.predix.io/view/getInvoiceSearchWithFilter",



	type: "post", //send it through post method



	data : postData,



	headers : {



'Content-Type' : 'application/json'

 },

success: function(responseData) {

    //  alert("search data available "+ JSON.stringify(responseData).length);



console.log("response data with filter"+responseData);

reloadMainGridData(responseData);

},



error: function ( xhr, status, error) {

 console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );

 }

 });

} */


$.ajax({

    url: "https://predix-aircraft-demo.run.aws-usw02-pr.ice.predix.io/getaircraftDetails",

  type: "get", //send it through post method

   success: function(responseData) {



   //  alert("search data available "+ JSON.stringify(responseData).length);



    console.log(responseData);

    reloadMainGridData(responseData);

 },

  error: function ( xhr, status, error) {

      console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );

    }

  });



 }

 function reloadMainGridData(newdata){

var rowData = $("#list").jqGrid("getGridParam", "data");

 jQuery("#list").jqGrid("clearGridData");

    jQuery("#list").jqGrid('setGridParam',

        {

            datatype: 'local',

            data:newdata

        })

    .trigger("reloadGrid");

 }

	$("#list").jqGrid({

		  //datatype: "local",

      width: 930,

		  height: 350,

			//autowidth: true,

			shrinkToFit: false,

			//forceFit: true,

			url : "https://predix-aircraft-demo.run.aws-usw02-pr.ice.predix.io/getaircraftDetails",

			datatype : "json",

			//mtype : 'POST',

		 	colNames: ['AirCraft ID', 'Air Speed', 'Arm Retardant Tank Door', 'Beacon Start Stop Recording', 'Elapsed Time', 'Elevator Position', 'Flap Position', 'Gear Up And Locked', 'Left Aileron Position', 'Peak Valley Indicator', 'Pressure Altitude', 'Record Type', 'Retardant Door Open', 'Retardant Tank Float', 'Roll Acceleration', 'Strain Gauge 1', 'Strain Gauge 2', 'Strain Gauge 3', 'Strain Gauge 4', 'Strain Gauge 5', 'Strain Gauge 6', 'Strain Gauge 7', 'Strain Gauge 8', 'Timestamp', 'Trigger Channel', 'Vertical Acceleration'],

  colModel: [{

		name: 'aircraftId',
		index: 'aircraftId',
		width: '75',
		sorttype: "text"

		}, {

		name: 'airspeed',
		index: 'airspeed',
		width: '70',
		sorttype: "float"

		}, {

		name: 'armRetardantTankDoor',
		index: 'armRetardantTankDoor',
		width: '150',
		sorttype: "float"

		}, {

		name: 'beaconStartStopRecording',
		index: 'beaconStartStopRecording',
		width: '170',
		sorttype: "float"

		}, {

		name: 'elapsedTime',
		index: 'elapsedTime',
		width: '80',
		sorttype: "float"

		}, {

		name: 'elevatorPosition',
		index: 'elevatorPosition',
		width: '100',
		sorttype: "float"

		}, {

		name: 'flapPosition',
		index: 'flapPosition',
		width: '90',
		sorttype: "float"

		}, {

		name: 'gearUpAndLocked',
		index: 'gearUpAndLocked',
		width: '120',
		sorttype: "float"

		}, {

		name: 'leftAileronPosition',
		index: 'leftAileronPosition',
		width: '120',
		sorttype: "text"

		}, {

		name: 'peakValleyIndicator',
		index: 'peakValleyIndicator',
		width: '140',
		sorttype: "text"

		}, {

		name: 'pressureAltitude',
		index: 'pressureAltitude',
		width: '120',
		sorttype: "float"

		}, {

		name: 'recordType',
		index: 'recordType',
		width: '80',
		sorttype: "text"

		}, {

		name: 'retardantDoorOpen',
		index: 'retardantDoorOpen',
		width: '130',
		sorttype: "float"

		}, {

		name: 'retardantTankFloat',
		index: 'retardantTankFloat',
		width: '150',
		sorttype: "float"

		}, {

		name: 'rollAcceleration',
		index: 'rollAcceleration',
		width: '110',
		sorttype: "float"

		}, {

		name: 'strainGauge1',
		index: 'strainGauge1',
		width: '100',
		sorttype: "float"

		}, {

		name: 'strainGauge2',
		index: 'strainGauge2',
		width: '100',
		sorttype: "float"

		}, {

		name: 'strainGauge3',
		index: 'strainGauge3',
		width: '100',
		sorttype: "float"

		}, {

		name: 'strainGauge4',
		index: 'strainGauge4',
		width: '100',
		sorttype: "float"

		}, {

		name: 'strainGauge5',
		index: 'strainGauge5',
		width: '100',
		sorttype: "float"

		}, {

		name: 'strainGauge6',
		index: 'strainGauge6',
		width: '100',
		sorttype: "float"

		}, {

		name: 'strainGauge7',
		index: 'strainGauge7',
		width: '100',
		sorttype: "float"

		}, {

		name: 'strainGauge8',
		index: 'strainGauge8',
		width: '100',
		sorttype: "float"

		}, {

		name: 'timestamp',
		index: 'timestamp',
		width: '70',
		sorttype: "float"

		}, {

		name: 'triggerChannel',
		index: 'triggerChannel',
		width: '110',
		sorttype: "text"

		}, {

		name: 'verticalAcceleration',
		index: 'verticalAcceleration',
		width: '140',
		sorttype: "float"

		}],

		pager : '#pager',

		rowNum : 10,

		rowList : [ 10, 20, 30 ],

		sortname : 'invid',

		sortorder : 'desc',

		multiselect: true,

		viewrecords : true,

		gridview : true,

		//caption : 'Supplier Connect',

		jsonReader : {

			//repeatitems : false,

		},

    loadComplete: function() {

      $("tr.jqgrow:odd").css("background", "#E0E0E0");

    $("tr.jqgrow:odd").css("background", "#E0E0E0");

    },

		gridComplete: function() {

			//updateStatus();

		},

	});

jQuery("#list").jqGrid('navGrid','#pager',{del:false,add:false,edit:false,search: false, refresh: false},{},{},{});


var names = ["aircraftId", "airspeed", "armRetardantTankDoor", "beaconStartStopRecording", "elapsedTime", "elevatorPosition", "flapPosition", "gearUpAndLocked", "leftAileronPosition", "peakValleyIndicator", "pressureAltitude", "recordType", "retardantDoorOpen", "retardantTankFloat", "rollAcceleration", "strainGauge1", "strainGauge2", "strainGauge3", "strainGauge4", "strainGauge5", "strainGauge6", "strainGauge7", "strainGauge8", "timestamp", "triggerChannel", "verticalAcceleration"];



	jQuery("#list").jqGrid('navGrid', '#pager', {

		edit : true,

		add : true,

		del : true,

		search : true

	});

});
