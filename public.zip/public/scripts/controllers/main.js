define(['./dashboard', './data-control', './sv-dashboard', './sv-charts'], function() {

});
