/*
 * load angular app.directives files - angular.module("app.directives");
 */
define(['./sample-directive'], function() {

});
