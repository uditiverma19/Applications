jQuery(document).ready(function() {

$("#paymentSubmitID").click(function (event) {

  var searchpaymentNumber = $("#paymentNumber").val();
  var searchpaymentDate = $("#paymentDate").val();
  var searchamount = $("#amount").val();
  var searchinvoiceNumber = $("#invoiceNumber").val();
  var searchPONbr = $("#poNumber").val();


searchGridData(searchpaymentNumber, searchpaymentDate, searchamount, searchinvoiceNumber, searchPONbr);


   });

  $("#paymentClearBtnID").click(function (event) {

    jQuery("#paymentNumber").val("");
    jQuery("#paymentDate").val("");
    jQuery("#amount").val("");
    jQuery("#invoiceNumber").val("");
    jQuery("#poNumber").val("");


    searchGridData('', '', '', '', '');


    });

    $("#csvSelect").change(function() {
		    multipleSelect = $("#csvSelect").val();
	  });

    $("#downloadButtonID").click(function (event) {
      var searchpaymentNumber = $("#paymentNumber").val();
      var searchpaymentDate = $("#paymentDate").val();
      var searchamount = $("#amount").val();
      var searchinvoiceNumber = $("#invoiceNumber").val();
      var searchPONbr = $("#poNumber").val();

      // alert(csvSelect);

  if(multipleSelect!=""){

    if(searchpaymentNumber !='' || searchpaymentDate !='' || searchamount !='' || searchinvoiceNumber !='' || searchPONbr !=''){
      //    window.location = 'http://scp-transport-demand-portal.run.aws-usw02-pr.ice.predix.io/view/downloadExcelSearchWithFilter/'+serchItmNbr+'/"'+serchBuyerNmID+'"/"'+searchSupplierNmID+'"/"'+supllierCode+'"/"'+searchBusinessID+'"';
      }

    else{
            window.location = 'https://scpcrpinvoicedetail.run.aws-usw02-pr.ice.predix.io/view/downloadExcelPmtWithoutFilter';
      }

      }

      else{
        searchGridData(searchpaymentNumber, searchpaymentDate, searchamount, searchinvoiceNumber, searchPONbr);
      }
  });


  function searchGridData(searchpaymentNumber, searchpaymentDate, searchamount, searchinvoiceNumber, searchPONbr){
    var searchitemdata = {paymentNumber:searchpaymentNumber, paymentDate:searchpaymentDate, amount:searchamount, invoiceNumber:searchinvoiceNumber, poNumber:searchPONbr};
	var postData = JSON.stringify(searchitemdata);
	console.log('resultData--filedSeletcedButtonID'+postData);

  if(searchpaymentNumber !='' || searchpaymentDate !='' || searchamount !='' || searchinvoiceNumber !='' || searchPONbr !=''){

    $.ajax({

	url: "https://scpcrpinvoice.run.aws-usw02-pr.ice.predix.io/view/getscpPaymentsearchWithFilter",

	type: "post", //send it through post methodOfPayment

	data : postData,

	headers : {

'Content-Type' : 'application/json'
 },
success: function(responseData) {
    //  alert("search data available "+ JSON.stringify(responseData).length);

console.log("response data with filter"+responseData);
reloadMainGridData(responseData);
},

error: function ( xhr, status, error) {
 console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
 }
 });
}
else {
$.ajax({
    url: "https://scpcrpinvoice.run.aws-usw02-pr.ice.predix.io/view/getscpPaymentsearchWithOutFilter",
  type: "get", //send it through post methodOfPayment
   success: function(responseData) {

   //  alert("search data available "+ JSON.stringify(responseData).length);

    console.log(responseData);
    reloadMainGridData(responseData);
 },
  error: function ( xhr, status, error) {
      console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
  });
	}
 }


 function reloadMainGridData(newdata){
var rowData = $("#list1").jqGrid("getGridParam", "data");
 jQuery("#list1").jqGrid("clearGridData");

    jQuery("#list1").jqGrid('setGridParam',

        {
            datatype: 'local',
            data:newdata
        })
    .trigger("reloadGrid");
 }




	$("#list1").jqGrid({
		  //datatype: "local",
      width: 930,
		  height: 230,
		url : "https://scpcrpinvoice.run.aws-usw02-pr.ice.predix.io/view/getscpPaymentsearchWithOutFilter",
		datatype : "json",
		//mtype : 'POST',
		 colNames: ['Payment Number', 'Remit-to Supplier', 'Remit-to Supplier Site', 'Payment Date', 'Currency', 'Amount', 'Method Of Payment', 'Status', 'Status Date', 'Bank Account', 'Invoice Number', 'PO Number'],
  colModel: [{
        name: 'paymentNumber',
    index: 'paymentNumber',
    width: 85,
    sorttype: "int"
  }, {
    name: 'remitToSupplier',
    index: 'remitToSupplier',
    width: 95,
    sorttype: "float"
  }, {
    name: 'remitToSupplierSite',
    index: 'remitToSupplierSite',
    width: 110,
    sorttype: "float"
  }, {
    name: 'paymentDate',
    index: 'paymentDate',
    width: 75,
    sorttype: "date"
  }, {
    name: 'currency',
    index: 'currency',
    width: 65,
    sorttype: "float"
  }, {
    name: 'amount',
    index: 'amount',
    width: 55,
    sorttype: "float"
  }, {
    name: 'methodOfPayment',
    index: 'methodOfPayment',
    width: 80,
    sorttype: "float"
  },{
    name: 'status',
    index: 'status',
    width: 45,
    sorttype: "float"
  },{
    name: 'statusDate',
    index: 'statusDate',
    width: 55,
    sorttype: "date"
  },{
    name: 'bankAccount',
    index: 'bankAccount',
    width: 80,
    sorttype: "float"
  },{
    name: 'invoiceNumber',
    index: 'invoiceNumber',
    width: 75,
    sorttype: "int"
  }, {
    name: 'poNumber',
    index: 'poNumber',
    width: 55,
    sorttype: "int"
  }],

		pager : '#pager',
		rowNum : 10,
		rowList : [ 10, 20, 30 ],
		sortname : 'invid',
		sortorder : 'desc',
		multiselect: true,
		viewrecords : true,
		gridview : true,
		//caption : 'Supplier Connect',
		jsonReader : {
			//repeatitems : false,
		},
    loadComplete: function() {
      $("tr.jqgrow:odd").css("background", "#E0E0E0");
    $("tr.jqgrow:odd").css("background", "#E0E0E0");
    },
		gridComplete: function() {
			//updateStatus();
		},

	});


jQuery("#list1").jqGrid('navGrid','#pager',{del:false,add:false,edit:false,search: false, refresh: false},{},{},{});


	/*function updateStatus(){
		var grid = $("#list");
		var rowData = $("#list").getDataIDs();


		var rows = grid.getDataIDs();
    for (var i = 0; i < rows.length; i++)
    {
       var status = grid.getCell(rows[i],"status");

        if(status == "Approved")
        {
			//alert('status'+status);
           $("#list").jqGrid('setRowData',rows[i],false, {color:'green'});
	}
	}

		/*for (var i = 0; i < rowData.length; i++)
		{
        $("#list").jqGrid('setRowData', rowData[i], false, {color:'red'});
		var rowId = rowData[i];
    var rowData = jQuery('#list').jqGrid ('getRowData', rowId);

    console.log(rowData.Phrase);
    console.log(rowId);

		}

	}*/
var names = ["paymentNumber", "remitToSupplier", "remitToSupplierSite", "paymentDate", "currency", "amount", "methodOfPayment", "status", "statusDate", "bankAccount", "invoiceNumber", "poNumber"];

	jQuery("#list1").jqGrid('navGrid', '#pager', {
		edit : true,
		add : true,
		del : true,
		search : true
	});
});
