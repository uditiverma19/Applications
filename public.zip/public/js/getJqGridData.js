jQuery(document).ready(function() {

$("#invoiceSubmitID").click(function (event) {

	var searchPONbr = $("#poNumber").val();

	var searchInvoiceNbr = $("#invoiceNumber").val();

	var searchInvoiceAmt = $("#amount").val();

	var searchInvoiceSbtDt = $("#invoiceDate").val();

	var searchPayNumber = $("#paymentNumber").val();

	//alert("searchPO"+searchPONbr);

searchGridData(searchPONbr, searchInvoiceNbr, searchInvoiceAmt, searchInvoiceSbtDt, searchPayNumber);

   });


  $("#invoiceClearBtnID").click(function (event) {

  jQuery("#poNumber").val("");

  jQuery("#invoiceNumber").val("");

  jQuery("#amount").val("");

  jQuery("#invoiceDate").val("");

  jQuery("#paymentNumber").val("");

  searchGridData('', '', '', '', '');

    });


  /* $("#multipleSelect1").change(function() {

      multipleSelect = $("#multipleSelect1").val();
	});

      function saveRows() {
		if(multipleSelect=="Save"){

              var grid = $("#list");

              var ids = grid.jqGrid('getDataIDs');

              var poNumber;

              for (var i = 0; i < ids.length; i++) {

                celValue = grid.jqGrid ('getCell', ids[1], 'quantityType');

               if ($('#jqg_list_'+ids[i]).is(':checked')){

                  poNumber = grid.jqGrid ('getCell', ids[i], 'poNumber');

                }

                if(celValue=="Planned for Supplier")

                {

                      grid.jqGrid('saveRow', ids[i]);

                      var rowEdit = grid.jqGrid('getRowData', ids[i]);

                      var saveRowdata = $("#list").jqGrid("getGridParam", "data");

                      var postRowdata = JSON.stringify(rowEdit).replace(/]|[[]/g, '');

                   // alert("rowData:  "+postRowdata);

                    console.log(postRowdata);

                 $.ajax({

                    url: "http://scp-transport-demand-portal.run.aws-usw02-pr.ice.predix.io/view/updateDemandDetails",

                    type: "POST", //send it through post method

                    data : postRowdata,

                    headers : {

                    'Content-Type' : 'application/json'

                  },

                success: function(responseData) {

                  jQuery('#list').jqGrid('setGridParam', {data: rowEdit});

                  var newGridData = $("#list").jqGrid("getGridParam", "data");

                  startEdit();

                  searchData('','','','');

                  //reloadMainGridData(newGridData);

                },

                error: function ( xhr, status, error) {

                    alert( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error);

                }

                });

                }

               }

             }

             else

             {

              alert("Select Save Option to proceed.");

             }

        } */


  function searchGridData(searchPONbr, searchInvoiceNbr, searchInvoiceAmt, searchInvoiceSbtDt, searchPayNumber){

    var searchitemdata = {poNumber:searchPONbr, invoiceNumber:searchInvoiceNbr, amount:searchInvoiceAmt, invoiceDate:searchInvoiceSbtDt, paymentNumber:searchPayNumber};

	var postData = JSON.stringify(searchitemdata);

	console.log('resultData--filedSeletcedButtonID'+postData);



if(searchPONbr !='' || searchInvoiceNbr !='' || searchInvoiceAmt !='' || searchInvoiceSbtDt !='' || searchPayNumber !=''){

$.ajax({



	url: "https://scpcrpinvoicedetail.run.aws-usw02-pr.ice.predix.io/view/getInvoiceSearchWithFilter",



	type: "post", //send it through post method



	data : postData,



	headers : {



'Content-Type' : 'application/json'

 },

success: function(responseData) {

    //  alert("search data available "+ JSON.stringify(responseData).length);



console.log("response data with filter"+responseData);

reloadMainGridData(responseData);

},



error: function ( xhr, status, error) {

 console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );

 }

 });

}

else {

$.ajax({

    url: "https://scpcrpinvoicedetail.run.aws-usw02-pr.ice.predix.io/view/getscpInvoiceearchWithOutFilter",

  type: "get", //send it through post method

   success: function(responseData) {



   //  alert("search data available "+ JSON.stringify(responseData).length);



    console.log(responseData);

    reloadMainGridData(responseData);

 },

  error: function ( xhr, status, error) {

      console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );

    }

  });

	}

 }

 function reloadMainGridData(newdata){

var rowData = $("#list").jqGrid("getGridParam", "data");

 jQuery("#list").jqGrid("clearGridData");

    jQuery("#list").jqGrid('setGridParam',

        {

            datatype: 'local',

            data:newdata

        })

    .trigger("reloadGrid");

 }

	$("#list").jqGrid({

		  //datatype: "local",

      width: 930,

		  height: 200,

		url : "https://scpcrpinvoicedetail.run.aws-usw02-pr.ice.predix.io/view/getscpInvoiceearchWithOutFilter",

		datatype : "json",

		//mtype : 'POST',

		 colNames: ['Invoice Number', 'Amount', 'Available Discount', 'Currency', 'Discount Date', 'Due', 'Due Date','Invoice Date', 'Invoice Type', 'On Hold', 'Payment Number', 'Payment Status', 'PO Number', 'Receipt', 'Remit-to Supplier', 'Remit-to Supplier Site', 'Status'],

  colModel: [{

		name: 'invoiceNumber',
		index: 'invoiceNumber',
		width: '70',
		sorttype: "text"

		}, {

		name: 'amount',
		index: 'amount',
		width: '50',
		sorttype: "float"

		}, {

		name: 'availableDiscount',
		index: 'availableDiscount',
		width: '80',
		sorttype: "float"

		}, {

		name: 'currency',
		index: 'currency',
		width: '50'

		}, {

		name: 'discountDate',
		index: 'discountDate',
		width: '60',
		sorttype: "date"

		}, {

		name: 'due',
		index: 'due',
		width: '40',
		sorttype: "float"

		}, {

		name: 'dueDate',
		index: 'dueDate',
		width: '50',
		sorttype: "date"

		}, {

		name: 'invoiceDate',
		index: 'invoiceDate',
		width: '55',
		sorttype: "date"

		}, {

		name: 'invoiceType',
		index: 'invoiceType',
		width: '55',
		sorttype: "text"

		}, {

		name: 'onHold',
		index: 'onHold',
		width: '40',
		sorttype: "text"

		}, {

		name: 'paymentNumber',
		index: 'paymentNumber',
		width: '70',
		sorttype: "int"

		}, {

		name: 'paymentStatus',
		index: 'paymentStatus',
		width: '70',
		sorttype: "text"

		}, {

		name: 'poNumber',
		index: 'poNumber',
		width: '60',
		sorttype: "int"

		}, {

		name: 'receipt',
		index: 'receipt',
		width: '50',
		sorttype: "int"

		}, {

		name: 'remitToSupplier',
		index: 'remitToSupplier',
		width: '70',
		sorttype: "text"

		}, {

		name: 'remitToSupplierSite',
		index: 'remitToSupplierSite',
		width: '75',
		sorttype: "text"

		}, {

		name: 'status',
		index: 'status',
		width: '50',
		sorttype: "text"

		}],

		pager : '#pager',

		rowNum : 10,

		rowList : [ 10, 20, 30 ],

		sortname : 'invid',

		sortorder : 'desc',

		multiselect: true,

		viewrecords : true,

		gridview : true,

		//caption : 'Supplier Connect',

		jsonReader : {

			//repeatitems : false,

		},

    loadComplete: function() {

      $("tr.jqgrow:odd").css("background", "#E0E0E0");

    $("tr.jqgrow:odd").css("background", "#E0E0E0");

    },

		gridComplete: function() {

			//updateStatus();

		},

	});

jQuery("#list").jqGrid('navGrid','#pager',{del:false,add:false,edit:false,search: false, refresh: false},{},{},{});


var names = ["invoiceNumber", "amount", "availableDiscount", "currency", "discountDate", "due", "dueDate", "invoiceDate", "invoiceType", "onHold", "paymentNumber", "paymentStatus", "poNumber", "receipt", "remitToSupplier", "remitToSupplierSite", "status"];



	jQuery("#list").jqGrid('navGrid', '#pager', {

		edit : true,

		add : true,

		del : true,

		search : true

	});

});
